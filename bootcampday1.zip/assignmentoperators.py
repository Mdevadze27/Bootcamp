a=b=c=10
print(a,b,c)

x,y=10,5

#x=x+y
x+=y
print(x)
x*=y #x=x*y
print(x)
