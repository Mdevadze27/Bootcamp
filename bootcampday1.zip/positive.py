x=-15

if x>0:
    print("Positive")
    print("Something")
if x<0:
    print("Negative")
else:
    print("Neither")
