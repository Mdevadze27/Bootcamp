x = int(input("Enter a number:"))

if x==0:print(x,"is zero")
elif x%2 == 0:print(x," is even")
else:print(x,"is odd")